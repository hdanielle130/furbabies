package com.furry.furbabies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FurbabiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
