package com.furry.furbabies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FurbabiesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FurbabiesApplication.class, args);
	}

}
